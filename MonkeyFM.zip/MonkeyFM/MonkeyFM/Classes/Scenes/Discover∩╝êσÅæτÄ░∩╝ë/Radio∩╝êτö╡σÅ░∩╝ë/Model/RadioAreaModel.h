//
//  RadioAreaModel.h
//  MonkeyFM
//
//  Created by 彭柞淞 on 16/6/30.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseModel.h"

@interface RadioAreaModel : BaseModel

@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *name;


@end
