//
//  RadioStyleSegmentedModel.m
//  MonkeyFM
//
//  Created by 彭柞淞 on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "RadioStyleSegmentedModel.h"

@implementation RadioStyleSegmentedModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
