//
//  ClassificationController.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/23.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseViewController.h"

@interface ClassificationController : BaseViewController

@end
