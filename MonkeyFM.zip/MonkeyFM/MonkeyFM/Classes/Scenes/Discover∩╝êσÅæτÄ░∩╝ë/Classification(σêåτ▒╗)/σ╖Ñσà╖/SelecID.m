//
//  SelecID.m
//  MonkeyFM
//
//  Created by 彭柞淞 on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "SelecID.h"

@implementation SelecID

singletion_implementation(SelecID)


@end
