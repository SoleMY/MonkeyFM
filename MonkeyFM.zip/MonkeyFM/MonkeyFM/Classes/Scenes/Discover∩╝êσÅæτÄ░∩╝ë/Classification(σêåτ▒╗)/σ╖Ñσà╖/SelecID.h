//
//  SelecID.h
//  MonkeyFM
//
//  Created by 彭柞淞 on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseModel.h"

@interface SelecID : BaseModel

@property (nonatomic, assign) NSInteger selectIndex;

singleton_interface(SelecID)


@end
