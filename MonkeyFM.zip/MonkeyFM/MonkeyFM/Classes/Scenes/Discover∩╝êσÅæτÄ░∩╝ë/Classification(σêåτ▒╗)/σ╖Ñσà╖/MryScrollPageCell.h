//
//  VCTableViewCell.h
//  MryNewsFrameWork
//
//  Created by mryun11 on 16/6/6.
//  Copyright © 2016年 mryun11. All rights reserved.
//


#import "BaseCell.h"

@interface MryScrollPageCell : BaseCell

@property (nonatomic,weak) UITableView *tableView;

@end
