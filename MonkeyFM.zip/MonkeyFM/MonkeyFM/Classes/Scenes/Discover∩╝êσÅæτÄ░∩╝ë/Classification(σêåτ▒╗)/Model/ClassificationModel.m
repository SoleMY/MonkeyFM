//
//  ClassificationModel.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/23.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "ClassificationModel.h"

@implementation ClassificationModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
