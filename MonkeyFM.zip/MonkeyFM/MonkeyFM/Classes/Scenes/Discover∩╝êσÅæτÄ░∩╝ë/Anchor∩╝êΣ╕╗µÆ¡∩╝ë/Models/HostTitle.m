//
//  HostTitle.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/25.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "HostTitle.h"

@implementation HostTitle

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
