//
//  AlbumCell.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/27.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "AlbumCell.h"
#import "CollectionViewCell.h"
#import "HeadCollectionReusableView.h"
@interface AlbumCell ()<UICollectionViewDelegate, UICollectionViewDataSource>

@end

@implementation AlbumCell
static NSString * const identifier_AlbumCell = @"identifier_Album";
static NSString * const identifier_HeaderCell = @"identifier_HeaderCell";

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle: style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initLayout];
        }
    return self;
}

- (void)initLayout {
    self.AlbumView = [[CollectionView alloc] initWithFrame: CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 150)];
    self.AlbumView.backgroundColor = [UIColor redColor];
    self.AlbumView.collectionView.delegate = self;
    self.AlbumView.collectionView.dataSource = self;
    [self.contentView addSubview:self.AlbumView];
    self.AlbumView.collectionView.scrollEnabled = NO;
    self.AlbumView.collectionView.showsVerticalScrollIndicator = NO;
    self.AlbumView.collectionView.bounces = NO;
    [self.AlbumView.collectionView registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:identifier_AlbumCell];
    [self.AlbumView.collectionView registerClass:[HeadCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:identifier_HeaderCell];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 2;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CollectionViewCell *cell = [self.AlbumView.collectionView dequeueReusableCellWithReuseIdentifier:identifier_AlbumCell forIndexPath:indexPath];
    cell.headPortrait.backgroundColor = [UIColor blueColor];
    cell.headPortrait.layer.cornerRadius = 0;
    cell.nameLabel.text = @"空空";
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        HeadCollectionReusableView *headView = [self.AlbumView.collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:identifier_HeaderCell forIndexPath:indexPath];
        headView.titleLabel.text = @"TA发布的专辑";
        return headView;
    }else {
        return nil;
    }
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(self.bounds.size.width, 20);
}


@end
