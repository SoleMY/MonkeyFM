//
//  HostViewController.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/25.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseViewController.h"

//typedef void(^Block)(id objc);
@interface HostViewController : BaseViewController
//@property (nonatomic, copy)Block block;

@property (nonatomic, strong) NSString *appendString;

@end
