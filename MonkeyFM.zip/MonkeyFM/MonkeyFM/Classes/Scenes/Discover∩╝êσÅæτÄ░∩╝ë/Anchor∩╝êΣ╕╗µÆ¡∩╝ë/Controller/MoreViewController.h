//
//  MoreViewController.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseViewController.h"

@interface MoreViewController : BaseViewController

@property (nonatomic, strong)NSString *appendStr;
@property (nonatomic, strong)NSString *uid;

@end
