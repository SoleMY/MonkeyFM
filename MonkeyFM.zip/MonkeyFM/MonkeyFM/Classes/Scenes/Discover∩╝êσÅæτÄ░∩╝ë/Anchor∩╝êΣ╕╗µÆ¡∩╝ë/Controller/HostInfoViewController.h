//
//  HostInfoViewController.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/26.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseViewController.h"

@interface HostInfoViewController : BaseViewController

@property (nonatomic, strong)NSString *uid;

@property (nonatomic, assign)CGFloat height;

@end
