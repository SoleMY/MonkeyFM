//
//  Host.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/25.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "Host.h"

@implementation Host

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
