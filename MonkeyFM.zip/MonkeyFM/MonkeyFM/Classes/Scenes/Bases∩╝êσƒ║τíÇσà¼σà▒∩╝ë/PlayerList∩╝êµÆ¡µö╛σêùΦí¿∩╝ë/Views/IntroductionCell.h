//
//  IntroductionCell.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/30.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseCell.h"

@interface IntroductionCell : BaseCell

@property (nonatomic, strong)UILabel *introductionLabel;

@property (nonatomic, strong)UILabel *introductionText;

@end
