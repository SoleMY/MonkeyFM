//
//  PlayList.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/30.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "PlayList.h"

@implementation PlayList

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
