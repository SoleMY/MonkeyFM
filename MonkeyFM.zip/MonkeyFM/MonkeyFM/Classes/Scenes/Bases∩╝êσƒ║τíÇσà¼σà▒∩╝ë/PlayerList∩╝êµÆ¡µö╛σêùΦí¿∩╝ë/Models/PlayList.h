//
//  PlayList.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/30.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlayList : NSObject

@property (nonatomic, strong)NSArray *host;
//@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *status;
@property (nonatomic, strong)NSString *updateDay;
@property (nonatomic, strong)NSString *copyrightLabel;
@property (nonatomic, strong)NSString *uploadUserName;
@property (nonatomic, strong)NSArray *keyWords;
@property (nonatomic, strong)NSString *radioDesc;

@end
