//
//  shufflingModel.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/23.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "shufflingModel.h"

@implementation shufflingModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
