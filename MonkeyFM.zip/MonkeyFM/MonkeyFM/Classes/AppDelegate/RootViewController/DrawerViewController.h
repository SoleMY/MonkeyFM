//
//  DrawerViewController.h
//  MonkeyFM
//
//  Created by 彭柞淞 on 16/6/23.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseViewController.h"

@interface DrawerViewController : BaseViewController

//@property (nonatomic, strong) UITableView *rearTableView;
@property (weak, nonatomic) IBOutlet UITableView *rearTableView;

@end
