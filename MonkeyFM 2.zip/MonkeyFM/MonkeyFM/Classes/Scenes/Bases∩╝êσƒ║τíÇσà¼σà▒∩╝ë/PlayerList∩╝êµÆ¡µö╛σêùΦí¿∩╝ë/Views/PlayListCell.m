//
//  PlayListCell.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/29.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "PlayListCell.h"
#import "UIImageView+LBBlurredImage.h"
@implementation PlayListCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initLayout];
    }
    return self;
}

- (void)initLayout {
    self.fuzzyImage = [[UIImageView alloc] init];
    [self.fuzzyImage sd_setImageWithURL:[NSURL URLWithString:@"http://image.kaolafm.net/mz/images/201510/79de75a0-c9fc-4d90-968d-e44acf139a9e/default.jpg"]];
    NSLog(@"%@", self.fuzzyImage.image);
// self.fuzzyImage.image = [self.fuzzyImage setImageToBlur: self.fuzzyImage.image blurRadius:21];
   
//    UIImageView *imageView = [[UIImageView alloc] init];
//    [imageView sd_setImageWithURL:[NSURL URLWithString:host.avatar]];
//    UIImage * image =  [imageView setImageToBlur:imageView.image blurRadius:21 ];
//    [self.bgTableView addScalableCoverWithImage: image smallImageURL:host.avatar];
   
    [self.contentView addSubview:self.fuzzyImage];

    
    [self.fuzzyImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(0);
        make.right.equalTo(self.contentView).offset(0);
        make.left.equalTo(self.contentView).offset(0);
        make.bottom.equalTo(self.contentView).offset(0);
    }];
#warning 为传值
//    self.smallImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"http://image.kaolafm.net/mz/images/201510/79de75a0-c9fc-4d90-968d-e44acf139a9e/default.jpg"]];
//    [self.contentView addSubview:self.smallImage];
//    [self.smallImage mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self).offset(30);
//        make.left.equalTo(self).offset((self.frame.size.width - 80 ) / 2);
//        make.width.mas_equalTo(80);
//        make.height.mas_equalTo(80);
//    }];
//    
//    self.listenTime = [[UILabel alloc] init];
//    self.listenTime.text = @"收听次数";
//    self.listenTime.font = [UIFont systemFontOfSize:13];
//    self.listenTime.textAlignment = NSTextAlignmentRight;
//    [self.contentView addSubview:self.listenTime];
//    [self.listenTime mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.smallImage.mas_bottom).offset(2);
//        make.left.equalTo(self).offset((self.frame.size.width - 80 ) / 2 - 20);
//        make.width.mas_equalTo(50);
//        make.height.mas_equalTo(20);
//    }];
//    
//    self.subscribePerson = [[UILabel alloc] init];
//    self.subscribePerson.text = @"订阅";
//    self.subscribePerson.font = [UIFont systemFontOfSize:13];
//    self.subscribePerson.textAlignment = NSTextAlignmentLeft;
//    [self.contentView addSubview:self.subscribePerson];
//    [self.subscribePerson mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.smallImage.mas_bottom).offset(2);
//        make.left.equalTo(self.listenTime.mas_right).offset(3);
//        make.width.mas_equalTo(100);
//        make.height.mas_equalTo(20);
//    }];
//    //    btn_radiodetail_share  btn_radiondetail_subcribe
//    self.subscribeButton = [[UIButton alloc] init];
//    self.subscribeButton.backgroundColor = [UIColor redColor];
//    [self.subscribeButton setImage:[UIImage imageNamed:@"btn_radiondetail_subcribe"] forState:UIControlStateNormal];
//    [self.contentView addSubview:self.subscribeButton];
//    [self.subscribeButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.listenTime.mas_bottom).offset(30);
//        make.right.equalTo(self.smallImage.mas_left).offset(10);
//        make.width.mas_equalTo(30);
//        make.height.mas_equalTo(50);
//    }];
//    
//    self.playButton = [[UIButton alloc] init];
//    [self.playButton setImage:[UIImage imageNamed:@"btn_radiodetail_share"] forState:UIControlStateNormal];
//    [self.contentView addSubview:self.playButton];
//    [self.playButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.listenTime.mas_bottom).offset(25);
//        make.left.equalTo(self.smallImage).offset(25);
//        make.width.mas_equalTo(15);
//        make.height.mas_equalTo(15);
//    }];
//    
//    self.shareButton = [[UIButton alloc] init];
//    [self.shareButton setImage:[UIImage imageNamed:@"播放button"] forState:UIControlStateNormal];
//    [self.contentView addSubview:self.shareButton];
//    [self.shareButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.listenTime.mas_bottom).offset(30);
//        make.left.equalTo(self.smallImage.mas_right).offset(10);
//        make.width.mas_equalTo(30);
//        make.height.mas_equalTo(50);
//    }];
}

@end
