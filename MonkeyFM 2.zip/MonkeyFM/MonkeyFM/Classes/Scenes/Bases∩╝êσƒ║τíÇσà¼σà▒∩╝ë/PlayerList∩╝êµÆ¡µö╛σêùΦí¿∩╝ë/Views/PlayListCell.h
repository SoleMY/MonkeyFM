//
//  PlayListCell.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/29.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseCell.h"

@interface PlayListCell : BaseCell

//模糊图
@property (nonatomic, strong)UIImageView *fuzzyImage;

//小视图
@property (nonatomic, strong)UIImageView *smallImage;

//收听次数
@property (nonatomic, strong)UILabel *listenTime;

//订阅人数
@property (nonatomic, strong)UILabel *subscribePerson;

//订阅按钮
@property (nonatomic, strong)UIButton *subscribeButton;

//播放按钮
@property (nonatomic, strong)UIButton *playButton;

//分享按钮
@property (nonatomic, strong)UIButton *shareButton;

@end
