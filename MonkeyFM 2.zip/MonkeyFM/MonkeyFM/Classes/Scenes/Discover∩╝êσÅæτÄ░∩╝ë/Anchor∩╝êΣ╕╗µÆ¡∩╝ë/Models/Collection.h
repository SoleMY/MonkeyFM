//
//  Collection.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/27.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Collection : NSObject

@property (nonatomic, strong)NSString *audioPic;

@property (nonatomic, strong)NSString *audioName;

@property (nonatomic, strong)NSString *updateTime;

@property (nonatomic, strong)NSString *albumName;

@end
