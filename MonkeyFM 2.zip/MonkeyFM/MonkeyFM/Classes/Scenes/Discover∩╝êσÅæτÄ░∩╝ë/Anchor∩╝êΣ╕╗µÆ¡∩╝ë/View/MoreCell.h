//
//  MoreCell.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "BaseCell.h"

@interface MoreCell : BaseCell

@property (nonatomic, strong)UIImageView *picture;
@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UILabel *subLabel;

@end
