//
//  Collect.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/28.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Collect : UICollectionViewCell

@property (nonatomic, strong)UIImageView *picture;

@property (nonatomic, strong)UILabel *titleLabel;

@property (nonatomic, strong)UILabel *decLabel;

@property (nonatomic, strong)UILabel *dateLabel;

@end
