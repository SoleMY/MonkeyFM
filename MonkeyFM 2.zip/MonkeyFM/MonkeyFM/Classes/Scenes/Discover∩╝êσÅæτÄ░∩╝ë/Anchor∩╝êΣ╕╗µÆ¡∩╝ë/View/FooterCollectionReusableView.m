//
//  FooterCollectionReusableView.m
//  MonkeyFM
//
//  Created by lanou3g on 16/6/24.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import "FooterCollectionReusableView.h"

@implementation FooterCollectionReusableView

@end
