//
//  SocialNetWork.h
//  MonkeyFM
//
//  Created by lanou3g on 16/6/27.
//  Copyright © 2016年 FGProject. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SocialNetWork : UICollectionViewCell
//图标
@property (nonatomic, strong)UIImageView *iconImage;

@end
