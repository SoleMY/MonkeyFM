//
//  MainTableView.h
//  MryNewsFrameWork
//
//  Created by mryun11 on 16/6/7.
//  Copyright © 2016年 mryun11. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseView.h"
@interface MryPageTable : UITableView

@property (nonatomic,copy) NSString *title;

@end
